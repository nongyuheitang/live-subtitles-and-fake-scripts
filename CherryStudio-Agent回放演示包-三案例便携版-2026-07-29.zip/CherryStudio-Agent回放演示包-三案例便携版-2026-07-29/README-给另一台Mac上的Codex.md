# Cherry Studio v2 三案例回放便携包

这是一个自包含素材包，供另一台 Mac 上的 Codex 根据当地用户名、安装目录和 Cherry Studio v2 数据库状态完成配置。它不包含一键安装器，也不会自动修改系统。

## 包内内容

- `examples/gzh-design-demo/`：公众号排版剧本、输入 DOCX、HTML 产物。
- `examples/embodied-intelligence-report/`：具身智能行业调研剧本、原 Session、PPTX 产物。
- `examples/foreign-investment-operations-report/`：数据报告剧本、原 Session、输入数据、报告模板、DOCX/XLSX 产物、XLSX 的 HTML 预览镜像和全部录制输出。
- `skills/gzh-design-replay/`：公众号案例所需的完整技能、组件库和脚本。
- `tool/provider-server.mjs`：统一 Provider 服务，支持 Anthropic 与 OpenAI SSE。
- `tool/mcp-toolbox.mjs`：离线 MCP 结果回放。
- `routes.json`：三案例相对路径路由；解压到任意目录均可解析。
- `deployment-spec.json`：机器可读的 Cherry v2 配置规格。
- `SHA256SUMS.txt`：全部交付文件的完整性校验。

## 目标结构

```text
Cherry Studio v2
   ↓
统一回放 Provider：http://127.0.0.1:8402
   ├─ 公众号排版 + minimax/minimax-m3 → gzh-design-demo
   ├─ 具身智能 + GLM-5.2             → embodied-intelligence-report
   ├─ 数据报告撰写 + GLM-5.2         → foreign-investment-operations-report
   └─ 其他请求                        → fallback
```

只有 Provider 使用网络端口 8402。两个 MCP 均为 stdio，不占用额外端口。

路由已经采用“首条用户提示词锁定”：后续工具结果即使出现其他案例关键词，也不会切换剧本。数据报告录制结果中包含过“具身智能”文件名，本版本已通过交叉污染测试，不会再误切到行业调研。

所有展示出来的交付文件卡都能在 Cherry 右侧预览：HTML、DOCX、PPTX 使用 Cherry 原生预览；XLSX 不直接展示文件卡，改为展示包含两张 Sheet 的 HTML 预览镜像，并在预览页内提供原始 XLSX 下载。当 HTML、XLSX 或 PPT/PPTX 已登记为最终交付物后，Provider 会立即静默结束，不再播放总结；同一会话后续任何输入也保持无回答。

## 给部署 Codex 的操作要点

1. 完整解压本包，并将解压目录作为 `PACKAGE_DIR`；部署完成后不要移动该目录。
2. 确认 Node.js 18+、python3、Cherry Studio v2 和端口 8402。
3. 启动统一 Provider：

   ```bash
   node "$PACKAGE_DIR/tool/provider-server.mjs" \
     --routes "$PACKAGE_DIR/routes.json" \
     --port 8402
   ```

4. 将 `skills/gzh-design-replay` 注册到 Cherry Studio 的技能目录。不要覆盖用户已有的 `gzh-design`；本包使用独立名称 `gzh-design-replay`。
5. 在同一个自定义 Anthropic Provider 下添加两个模型：`minimax/minimax-m3` 与 `GLM-5.2`。
6. 按 `deployment-spec.json` 创建两个 stdio MCP、三个回放 Agent 和三个工作区。
7. 三个 Agent 均使用 Full Auto / `bypassPermissions`。公众号三个模型槽均选 MiniMax；另外两个 Agent 的三个模型槽均选 GLM-5.2。
8. Provider、MCP、Agent 配置完成后重启 Cherry Studio，再分别使用固定提示词做首轮验证。
9. 逐一点击 HTML、DOCX、PPTX 和 XLSX 预览 HTML 文件卡，检查 Cherry 右侧预览；数据报告预览页还应能下载原始 XLSX。交付后模型不再输出文字为预期行为。

## 启动前检查

```bash
jq empty "$PACKAGE_DIR/routes.json" "$PACKAGE_DIR/deployment-spec.json"
node --check "$PACKAGE_DIR/tool/provider-server.mjs"
node --check "$PACKAGE_DIR/tool/mcp-toolbox.mjs"
curl http://127.0.0.1:8402/v1/models
```

`/v1/models` 应同时返回：

- `minimax/minimax-m3`
- `GLM-5.2`

## 兼容边界

- 数据库自动配置应先备份目标 Mac 的 `cherrystudio.sqlite`，再根据目标版本的实际表结构写入；不要直接照搬其他机器的数据库文件。
- 需要 Cherry Studio v2 提供 Agent 原生的 Bash、Read、Write、Edit、Skill、Task 和 `report_artifacts` 等工具卡。
- 完整数据报告回放约 15 分钟；首轮握手验证可用非流式请求检查路由，不必立即跑完整剧本。
