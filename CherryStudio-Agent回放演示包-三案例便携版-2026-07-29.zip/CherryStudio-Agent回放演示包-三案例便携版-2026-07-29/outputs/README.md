# 回放输出目录

统一 Provider 的相对路径路由会把三个案例的输出分别写入：

- `gzh-design-demo/`
- `embodied-intelligence-report/`
- `foreign-investment-operations-report/`

部署 Codex 可直接把这些目录设置成对应 Agent 的工作区。
