# -*- coding: utf-8 -*-
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from collections import defaultdict

SRC = '/Users/cherryai/Downloads/数据0528.xlsx'
OUT = '/Users/cherryai/Library/Application Support/CherryStudio/Data/Agents/system/2026-07-29/939cc4b3-a717-45ae-a229-b65d66b1b708/上海市外商投资企业运营数据分析表.xlsx'

src = openpyxl.load_workbook(SRC, data_only=True)
sws = src['Sheet1']
headers = [sws.cell(row=1, column=c).value for c in range(1, sws.max_column+1)]

# Read all data rows
all_rows=[]
for r in range(2, sws.max_row+1):
    rowvals=[sws.cell(row=r, column=c).value for c in range(1, sws.max_column+1)]
    if rowvals[6] is None: continue
    all_rows.append(rowvals)

def num(v):
    try: return float(v)
    except: return None

# Parse into dicts
D=[]
for rv in all_rows:
    D.append({
        'name':rv[6],'district':rv[5],'industry_b':rv[7],'industry_m':rv[8],
        'rev24':num(rv[22]),'rev23':num(rv[23]),'rev22':num(rv[24]),
        'tax24':num(rv[31]),'tax23':num(rv[32]),'tax22':num(rv[33]),
        'profit24':num(rv[40]),'profit23':num(rv[41]),'profit22':num(rv[42]),
        'emp24':num(rv[12]),'emp23':num(rv[13]),'emp22':num(rv[14]),
        'foreign24':num(rv[15]),'mainrev24':num(rv[25]),
    })
N=len(D)

# ---------- Styles ----------
TITLE_FILL = PatternFill('solid', fgColor='1F4E78')
HDR_FILL = PatternFill('solid', fgColor='2E75B6')
SUB_FILL = PatternFill('solid', fgColor='D6E4F0')
TOT_FILL = PatternFill('solid', fgColor='FCE4D6')
WHITE = Font(color='FFFFFF', bold=True, size=11)
TITLE_FONT = Font(color='FFFFFF', bold=True, size=14)
BOLD = Font(bold=True)
thin = Side(style='thin', color='BFBFBF')
BORDER = Border(left=thin,right=thin,top=thin,bottom=thin)
CENTER = Alignment(horizontal='center', vertical='center', wrap_text=True)
LEFT = Alignment(horizontal='left', vertical='center', wrap_text=True)
RIGHT = Alignment(horizontal='right', vertical='center')

wb = Workbook()

# =========================================================
# Sheet1: 原始明细
# =========================================================
ws1 = wb.active
ws1.title = '原始明细'

# Select key columns to include (clean readable subset) - include all useful cols
col_map = [
    (0,'序号'),(5,'所属区县'),(6,'企业名称'),(7,'主营产业'),(8,'行业门类'),(9,'行业大类'),
    (12,'2024从业人数'),(13,'2023从业人数'),(14,'2022从业人数'),
    (15,'2024外籍职工'),(16,'2024大学及以上'),
    (22,'2024营业收入(万元)'),(23,'2023营业收入(万元)'),(24,'2022营业收入(万元)'),
    (25,'2024主营收入(万元)'),(26,'2024营业费用'),(27,'2024营业成本'),(28,'2024研发投入'),(30,'2022研发投入'),
    (31,'2024纳税总额(万元)'),(32,'2023纳税总额(万元)'),(33,'2022纳税总额(万元)'),
    (34,'2024增值税'),(37,'2024企业所得税'),(38,'2024个人所得税'),
    (40,'2024利润总额(万元)'),(41,'2023利润总额(万元)'),(42,'2022利润总额(万元)'),
    (43,'2024净利润(万元)'),(44,'2023净利润(万元)'),(45,'2022净利润(万元)'),
    (57,'2024资产(万元)'),(58,'2023资产(万元)'),(59,'2022资产(万元)'),
    (65,'2024负债(万元)'),(66,'2023负债(万元)'),
    (71,'2024所有者权益(万元)'),(73,'2023所有者权益(万元)'),
    (20,'注册资本(万美元)'),(21,'投资总额(万美元)'),
]

# Title row
ws1.merge_cells(start_row=1,start_column=1,end_row=1,end_column=len(col_map))
c=ws1.cell(row=1,column=1,value='2024年度上海市外商投资企业年报数据原始明细（共200家企业）')
c.font=TITLE_FONT; c.fill=TITLE_FILL; c.alignment=CENTER
ws1.row_dimensions[1].height=30

# Header
for j,(idx,name) in enumerate(col_map,1):
    c=ws1.cell(row=2,column=j,value=name)
    c.font=WHITE; c.fill=HDR_FILL; c.alignment=CENTER; c.border=BORDER
ws1.row_dimensions[2].height=32

# Data
for i,rv in enumerate(all_rows,1):
    for j,(idx,name) in enumerate(col_map,1):
        v=rv[idx]
        c=ws1.cell(row=2+i,column=j,value=v)
        c.border=BORDER
        if isinstance(v,float):
            c.number_format='#,##0.00'
            c.alignment=RIGHT
        elif isinstance(v,int):
            c.number_format='#,##0'
            c.alignment=RIGHT
        else:
            c.alignment=LEFT if j in (2,3) else CENTER

# Column widths
widths={1:6,2:10,3:12,4:10,5:24,6:18,7:11,8:11,9:11,10:10,11:12,12:18,13:18,14:18,15:16,16:12,17:12,18:12,19:12,20:18,21:18,22:18,23:12,24:14,25:14,26:18,27:18,28:18,29:16,30:16,31:16,32:16,33:16,34:16,35:16,36:16,37:16,38:16}
for j,(idx,name) in enumerate(col_map,1):
    ws1.column_dimensions[get_column_letter(j)].width=widths.get(j,14)

ws1.freeze_panes='C3'
ws1.auto_filter.ref=f"A2:{get_column_letter(len(col_map))}{2+len(all_rows)}"

# =========================================================
# Sheet2: 重点指标趋势摘要
# =========================================================
ws2 = wb.create_sheet('重点指标趋势摘要')

r=1
# Section title
ws2.merge_cells(start_row=r,start_column=1,end_row=r,end_column=8)
c=ws2.cell(row=r,column=1,value='2024年度上海市外商投资企业运营重点指标趋势摘要')
c.font=TITLE_FONT; c.fill=TITLE_FILL; c.alignment=CENTER
ws2.row_dimensions[r].height=30
r+=2

def section_header(title, row):
    ws2.merge_cells(start_row=row,start_column=1,end_row=row,end_column=8)
    c=ws2.cell(row=row,column=1,value=title)
    c.font=Font(bold=True,size=12,color='1F4E78'); c.fill=SUB_FILL; c.alignment=LEFT
    ws2.row_dimensions[row].height=24
    return row+1

def write_table(headers, data_rows, start_row, total_row=None):
    # headers
    for j,h in enumerate(headers,1):
        c=ws2.cell(row=start_row,column=j,value=h)
        c.font=WHITE; c.fill=HDR_FILL; c.alignment=CENTER; c.border=BORDER
    ws2.row_dimensions[start_row].height=30
    rr=start_row+1
    for dr in data_rows:
        for j,v in enumerate(dr,1):
            c=ws2.cell(row=rr,column=j,value=v)
            c.border=BORDER
            if isinstance(v,float):
                c.number_format='#,##0.0'; c.alignment=RIGHT
            elif isinstance(v,int):
                c.number_format='#,##0'; c.alignment=RIGHT
            else:
                c.alignment=CENTER if j>1 else LEFT
        rr+=1
    if total_row:
        for j,v in enumerate(total_row,1):
            c=ws2.cell(row=rr,column=j,value=v)
            c.border=BORDER; c.font=BOLD; c.fill=TOT_FILL
            if isinstance(v,float):
                c.number_format='#,##0.0'; c.alignment=RIGHT
            elif isinstance(v,int):
                c.number_format='#,##0'; c.alignment=RIGHT
            else:
                c.alignment=CENTER if j>1 else LEFT
        rr+=1
    return rr+1

# ---- Section 1: 整体经营指标三年趋势 ----
r=section_header('一、整体经营指标三年趋势（2022—2024年）', r)
def S(k): return sum(x[k] for x in D if x[k] is not None)
rev24,rev23,rev22=S('rev24'),S('rev23'),S('rev22')
tax24,tax23,tax22=S('tax24'),S('tax23'),S('tax22')
pf24,pf23,pf22=S('profit24'),S('profit23'),S('profit22')
emp24,emp23,emp22=S('emp24'),S('emp23'),S('emp22')
f24=S('foreign24')
def gr(a,b): return round((a-b)/b*100,1) if b else None
h=['指标','2024年','2023年','2022年','24年同比(%)','23年同比(%)']
data=[
 ['销售收入(万元)',round(rev24,1),round(rev23,1),round(rev22,1),gr(rev24,rev23),gr(rev23,rev22)],
 ['纳税总额(万元)',round(tax24,1),round(tax23,1),round(tax22,1),gr(tax24,tax23),gr(tax23,tax22)],
 ['利润总额(万元)',round(pf24,1),round(pf23,1),round(pf22,1),gr(pf24,pf23),gr(pf23,pf22)],
 ['利润率(%)',round(pf24/rev24*100,2),round(pf23/rev23*100,2),round(pf22/rev22*100,2),
   round(pf24/rev24*100-pf23/rev23*100,2),round(pf23/rev23*100-pf22/rev22*100,2)],
 ['从业人数(人)',int(emp24),int(emp23),int(emp22),gr(emp24,emp23),gr(emp23,emp22)],
 ['外籍从业人数(人)',int(f24),'—','—','—','—'],
 ['户均收入(万元)',round(rev24/N,1),round(rev23/N,1),round(rev22/N,1),gr(rev24/N,rev23/N),gr(rev23/N,rev22/N)],
 ['企业数量(家)',N,N,N,0,0],
]
r=write_table(h,data,r)

# ---- Section 2: 按区县分布 ----
r=section_header('二、按区县分布（2024年）', r)
dd=defaultdict(lambda:{'n':0,'rev24':0,'rev23':0,'tax24':0,'tax23':0,'profit24':0,'profit23':0,'emp24':0,'foreign':0})
for x in D:
    if x['district'] is None: continue
    dd[x['district']]['n']+=1
    for f in ['rev24','rev23','tax24','tax23','profit24','profit23','emp24','foreign']:
        if x[f] is not None: dd[x['district']][f]+=x[f]
h=['区县','企业数(家)','2024收入(万元)','收入占比(%)','收入同比(%)','户均收入(万元)','2024纳税(万元)','从业人数(人)']
data=[]
for k in sorted(dd,key=lambda x:-dd[x]['rev24']):
    v=dd[k]
    g=gr(v['rev24'],v['rev23']) if v['rev23'] else None
    avg=round(v['rev24']/v['n'],1) if v['n'] else 0
    data.append([k,v['n'],round(v['rev24'],1),round(v['rev24']/rev24*100,1),g,avg,round(v['tax24'],1),int(v['emp24'])])
tot=['合计',N,round(rev24,1),100.0,gr(rev24,rev23),round(rev24/N,1),round(tax24,1),int(emp24)]
r=write_table(h,data,r,tot)

# ---- Section 3: 按行业门类分布 ----
r=section_header('三、按行业门类分布（2024年）', r)
ind=defaultdict(lambda:{'n':0,'rev24':0,'rev23':0,'tax24':0,'tax23':0,'profit24':0,'profit23':0,'emp24':0})
for x in D:
    if x['industry_m'] is None: continue
    ind[x['industry_m']]['n']+=1
    for f in ['rev24','rev23','tax24','tax23','profit24','profit23','emp24']:
        if x[f] is not None: ind[x['industry_m']][f]+=x[f]
h=['行业门类','企业数(家)','2024收入(万元)','收入占比(%)','收入同比(%)','2024纳税(万元)','2024利润(万元)','利润同比(%)']
data=[]
for k in sorted(ind,key=lambda x:-ind[x]['rev24']):
    v=ind[k]
    gr_r=gr(v['rev24'],v['rev23']) if v['rev23'] else None
    gr_p=gr(v['profit24'],v['profit23']) if v['profit23'] else None
    data.append([k,v['n'],round(v['rev24'],1),round(v['rev24']/rev24*100,1),gr_r,round(v['tax24'],1),round(v['profit24'],1),gr_p])
tot=['合计',N,round(rev24,1),100.0,gr(rev24,rev23),round(tax24,1),round(pf24,1),gr(pf24,pf23)]
r=write_table(h,data,r,tot)

# ---- Section 4: 按产业分布 ----
r=section_header('四、按产业分布（2024年）', r)
cy=defaultdict(lambda:{'n':0,'rev24':0,'rev23':0,'tax24':0,'profit24':0,'emp24':0})
for x in D:
    if x['industry_b'] is None: continue
    cy[x['industry_b']]['n']+=1
    for f in ['rev24','rev23','tax24','profit24','emp24']:
        if x[f] is not None: cy[x['industry_b']][f]+=x[f]
h=['产业','企业数(家)','2024收入(万元)','收入占比(%)','收入同比(%)','2024纳税(万元)','2024利润(万元)','从业人数(人)']
data=[]
for k in sorted(cy,key=lambda x:-cy[x]['rev24']):
    v=cy[k]
    g=gr(v['rev24'],v['rev23']) if v['rev23'] else None
    data.append([k,v['n'],round(v['rev24'],1),round(v['rev24']/rev24*100,1),g,round(v['tax24'],1),round(v['profit24'],1),int(v['emp24'])])
r=write_table(h,data,r)

# ---- Section 5: 收入区间分布 ----
r=section_header('五、销售收入区间分布（2024年）', r)
ranges=[(0,100,'100万元以下'),(100,1000,'100万—1000万元'),(1000,10000,'1000万—1亿元'),(10000,100000,'1亿—10亿元'),(100000,float('inf'),'10亿元以上')]
h=['收入区间','企业数(家)','企业占比(%)','收入合计(万元)','收入占比(%)','收入同比(%)']
data=[]
for lo,hi,label in ranges:
    sub=[x for x in D if x['rev24'] is not None and lo<=x['rev24']<hi]
    rs=sum(x['rev24'] for x in sub)
    rs23=sum(x['rev23'] for x in sub if x['rev23'])
    g=gr(rs,rs23) if rs23 else None
    data.append([label,len(sub),round(len(sub)/N*100,1),round(rs,1),round(rs/rev24*100,1),g])
r=write_table(h,data,r)

# ---- Section 6: 收入TOP10企业 ----
r=section_header('六、销售收入TOP10企业（2024年）', r)
top=sorted([x for x in D if x['rev24']],key=lambda x:-x['rev24'])[:10]
h=['排名','企业名称','所属区县','行业门类','2024收入(万元)','2023收入(万元)','同比(%)','2024利润(万元)']
data=[]
for i,x in enumerate(top,1):
    g=gr(x['rev24'],x['rev23']) if x['rev23'] else None
    data.append([i,x['name'],x['district'],x['industry_m'],round(x['rev24'],1),round(x['rev23'],1) if x['rev23'] else None,g,round(x['profit24'],1) if x['profit24'] is not None else None])
r=write_table(h,data,r)

# Column widths for sheet2
for j in range(1,9):
    ws2.column_dimensions[get_column_letter(j)].width=[26,16,18,14,14,18,18,14][j-1]

wb.save(OUT)
print("Saved:", OUT)
print("Sheet1 rows:", ws1.max_row, "Sheet2 rows:", ws2.max_row)