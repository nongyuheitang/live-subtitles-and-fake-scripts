# -*- coding: utf-8 -*-
"""基于2024年报真实数据，将2023模板更新为2024年度运营报告"""
import openpyxl
from collections import defaultdict
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

SRC='/Users/cherryai/Downloads/数据0528.xlsx'
TPL='/Users/cherryai/Downloads/2023上海市外商投资企业运营报告_模板.docx'
OUT='/Users/cherryai/Library/Application Support/CherryStudio/Data/Agents/system/2026-07-29/939cc4b3-a717-45ae-a229-b65d66b1b708/2024上海市外商投资企业运营报告.docx'

# ---------- load data ----------
src=openpyxl.load_workbook(SRC,data_only=True); sws=src['Sheet1']
def num(v):
    try: return float(v)
    except: return None
D=[]
for r in range(2,sws.max_row+1):
    g=lambda c: sws.cell(row=r,column=c).value
    if g(7) is None: continue
    D.append({'name':g(7),'district':g(6),'industry_b':g(8),'industry_m':g(9),
        'rev24':num(g(23)),'rev23':num(g(24)),'rev22':num(g(25)),
        'tax24':num(g(32)),'tax23':num(g(33)),'tax22':num(g(34)),
        'profit24':num(g(41)),'profit23':num(g(42)),'profit22':num(g(43)),
        'emp24':num(g(13)),'emp23':num(g(14)),'emp22':num(g(15)),
        'foreign24':num(g(16)),'mainrev24':num(g(26)),'reported':g(2)})
N=len(D)
S=lambda k: sum(x[k] for x in D if x[k] is not None)
rev24,rev23,rev22=S('rev24'),S('rev23'),S('rev22')
tax24,tax23,tax22=S('tax24'),S('tax23'),S('tax22')
pf24,pf23,pf22=S('profit24'),S('profit23'),S('profit22')
emp24,emp23,emp22=S('emp24'),S('emp23'),S('emp22')
f24=S('foreign24')
def gr(a,b): return (a-b)/b*100 if b else 0
def yi(w): return w/10000.0
def W2Y(w): return round(yi(w),2)
avg_rev=rev24/N; avg_rev23=rev23/N

def group_by(key):
    d=defaultdict(lambda:{'n':0,'rev24':0,'rev23':0,'tax24':0,'tax23':0,'profit24':0,'profit23':0,'emp24':0,'emp23':0,'foreign':0})
    for x in D:
        k=x[key]
        if k is None: continue
        d[k]['n']+=1
        for f in ['rev24','rev23','tax24','tax23','profit24','profit23','emp24','emp23']:
            if x.get(f) is not None: d[k][f]+=x[f]
        if x.get('foreign24') is not None: d[k]['foreign']+=x['foreign24']
    return d
dd=group_by('district'); ind=group_by('industry_m'); cy=group_by('industry_b')

# rankings
dist_rev_rank=sorted(dd.items(),key=lambda x:-x[1]['rev24'])
ind_cnt_rank=sorted(ind.items(),key=lambda x:-x[1]['n'])
ind_rev_rank=sorted(ind.items(),key=lambda x:-x[1]['rev24'])
ind_tax_rank=sorted(ind.items(),key=lambda x:-x[1]['tax24'])
ind_pf_rank=sorted(ind.items(),key=lambda x:-x[1]['profit24'])

# revenue ranges
ranges_def=[(0,100,'100万元以下'),(100,1000,'100万—1000万元'),(1000,10000,'1000万—1亿元'),(10000,100000,'1亿—10亿元'),(100000,float('inf'),'10亿元以上')]
def range_stat(lo,hi):
    sub=[x for x in D if x['rev24'] is not None and lo<=x['rev24']<hi]
    rs=sum(x['rev24'] for x in sub); rs23=sum(x['rev23'] for x in sub if x['rev23'])
    return len(sub),rs,(rs-rs23)/rs23*100 if rs23 else 0
top_rev=sorted([x for x in D if x['rev24']],key=lambda x:-x['rev24'])

# district growth (exclude base<=100万 to avoid distortion), only meaningful
dgrowth_all=[(k,v,(v['rev24']-v['rev23'])/v['rev23']*100) for k,v in dd.items() if v['rev23']>100]
dgrowth_all.sort(key=lambda x:-x[2])
# district avg revenue
davg=[(k,v['rev24']/v['n']) for k,v in dd.items() if v['n']>0]
davg.sort(key=lambda x:-x[2])
above_avg=[k for k,a in davg if a>avg_rev]

# helpers for text
def pct(x,dec=1): return f"{x:.{dec}f}%"
def pct0(x): return f"{x:.0f}%"

# ========== Open template & replace ==========
doc=Document(TPL)
paras=doc.paragraphs

def set_para(p, text):
    """Set paragraph text preserving its first run's formatting; clear other runs."""
    if not p.runs:
        p.add_run(text); return
    # keep first run format
    first=p.runs[0]
    first.text=text
    for run in p.runs[1:]:
        run.text=''

# Map by paragraph index (from inspection). Replace text content.
# --- TOC entries (idx 0-2 area): update year 2023 -> 2024 ---
# We'll update paragraphs by their index captured earlier.

# Re-list to confirm indices quickly
idx_map={}
for i,p in enumerate(doc.paragraphs):
    t=p.text.strip()
    idx_map[i]=t

# ===== Section headings: 2023 -> 2024 =====
# idx3: 一、2023年度...概况
set_para(doc.paragraphs[3], "一、2024年度上海市外商投资企业年度报告概况")
# idx31: 二、2023年度...经营情况
set_para(doc.paragraphs[31], "二、2024年度上海市参加年度报告的外商投资企业经营情况")

# idx18: 2023年度上海市外商投资企业运营情况呈现以下特点
set_para(doc.paragraphs[18], "2024年度上海市外商投资企业运营情况呈现以下特点：")

# ---------- idx5: 参报概况 ----------
new_p5=(f"截至2025年12月1日，上海市参加2024年度外商投资企业年度报告填报的企业共{N}家"
        f"（以下简称「年报企业」）。年报企业数量同比增长约{pct0(gr(N,N)*0+0)}%。"  # N same as last cycle sample; keep neutral
        )
# Actually we don't have last-year count reliably; rephrase without false claim
new_p5=(f"截至2025年12月1日，上海市参加2024年度外商投资企业年度报告填报的企业共{N}家"
        f"（以下简称「年报企业」），覆盖全市16个行政区中的{len(dd)}个行政区，产业与行业分布较为广泛。")
set_para(doc.paragraphs[5], new_p5)

# ---------- idx6: 各区企业数量前三 ----------
top3_cnt=dist_rev_rank[:3]
parts='、'.join([f"{k}{v['n']}家" for k,v in sorted(dd.items(),key=lambda x:-x[1]['n'])[:3]])
top3cnt=sorted(dd.items(),key=lambda x:-x[1]['n'])[:3]
new_p6=(f"从年报企业所属行政区来看，2024年度企业数量排名前三位的行政区为"
        f"{top3cnt[0][0]}{top3cnt[0][1]['n']}家、{top3cnt[1][0]}{top3cnt[1][1]['n']}家和{top3cnt[2][0]}{top3cnt[2][1]['n']}家，"
        f"分别占年报企业数的{pct(top3cnt[0][1]['n']/N*100)}、{pct(top3cnt[1][1]['n']/N*100)}和{pct(top3cnt[2][1]['n']/N*100)}（见图1-1）。")
set_para(doc.paragraphs[6], new_p6)

# ---------- idx10: 产业分布 ----------
c3=cy.get('第三产业',{'n':0,'rev24':0}); c2=cy.get('第二产业',{'n':0,'rev24':0}); c1=cy.get('第一产业',{'n':0,'rev24':0})
n3=c3['n']; n2=c2['n']; n1=c1['n']
new_p10=(f"从产业分布来看，年报企业主要分布在第三产业，共{n3}家，占年报企业数的{pct(n3/N*100)}；"
         f"其次为第二产业{n2}家，占年报企业数的{pct(n2/N*100)}；第一产业{n1}家，占年报企业数的{pct(n1/N*100,1)}（见图1-2）。")
set_para(doc.paragraphs[10], new_p10)

# ---------- idx14: 行业前三 ----------
ic3=ind_cnt_rank[:3]
new_p14=(f"从具体行业看，2024年度年报企业数量排名前三位的行业分别为{ic3[0][0]}{ic3[0][1]['n']}家、"
         f"{ic3[1][0]}{ic3[1][1]['n']}家、{ic3[2][0]}{ic3[2][1]['n']}家，"
         f"分别占年报企业总数的{pct(ic3[0][1]['n']/N*100)}、{pct(ic3[1][1]['n']/N*100)}、{pct(ic3[2][1]['n']/N*100)}（见图1-3）。")
set_para(doc.paragraphs[14], new_p14)

# ---------- idx19: (一)整体经营表现 标题 ----------
set_para(doc.paragraphs[19], "（一）整体经营增收稳岗，但利润大幅承压")
# ---------- idx20: 整体指标 ----------
new_p20=(f"2024年度，年报企业销售（营业）收入合计{W2Y(rev24)}亿元，同比上升{pct(gr(rev24,rev23))}；"
         f"纳税总额{W2Y(tax24):.2f}亿元，同比上升{pct(gr(tax24,tax23))}；"
         f"利润总额{W2Y(pf24):.2f}亿元，同比下降{pct(abs(gr(pf24,pf23)))}，利润率为{pct(pf24/rev24*100,2)}，同比下降{pct(abs(pf24/rev24*100-pf23/rev23*100),2)}个百分点；"
         f"从业人数{int(emp24)}人，同比上升{pct(gr(emp24,emp23))}，其中，外籍从业人数{int(f24)}人。"
         f"总体来看，年报企业呈现「增收、增税、增就业」的良好态势，但受部分行业利润大幅回落影响，整体盈利能力较上年明显走弱。")
set_para(doc.paragraphs[20], new_p20)

# ---------- idx21: (二)行业 标题 ----------
set_para(doc.paragraphs[21], "（二）批发零售业、制造业经营规模领先，制造业盈利能力表现突出")
# ---------- idx22: 行业经营 ----------
ir=ind_rev_rank[:3]; it=ind_tax_rank[:3]; ip=ind_pf_rank[:3]
# manufacturing detail
mfg=ind.get('制造业',{'rev24':0,'tax24':0,'profit24':0,'rev23':0,'tax23':0,'profit23':0,'n':0})
new_p22=(f"2024年度，在年报企业的销售（营业）收入、纳税总额、利润总额和就业人数这四项经营指标中，"
         f"{ir[0][0]}、{ir[1][0]}、{ir[2][0]}均排名收入规模前三。其中，制造业经营指标成长性与盈利能力更为突出。"
         f"制造业销售（营业）收入合计{W2Y(mfg['rev24'])}亿元，同比增长{pct(gr(mfg['rev24'],mfg['rev23']))}，"
         f"位列行业收入规模第二；纳税总额合计{W2Y(mfg['tax24']):.2f}亿元，同比增长{pct(gr(mfg['tax24'],mfg['tax23']))}，位列行业纳税首位；"
         f"利润总额合计{W2Y(mfg['profit24']):.2f}亿元，同比增长{pct(gr(mfg['profit24'],mfg['profit23']))}，位列行业利润首位，是规模前三行业中唯一实现收入、利润双增长的行业。")
set_para(doc.paragraphs[22], new_p22)

# ---------- idx23: (三)区县 标题 ----------
set_para(doc.paragraphs[23], "（三）浦东新区经营规模全面领先，长宁区、闵行区、普陀区增速位居前列")
# ---------- idx24: 收入前三区 ----------
dr=dist_rev_rank[:3]
new_p24=(f"从销售（营业）收入总额来看，2024年度排名前三位的所属行政区分别为"
         f"{dr[0][0]}{W2Y(dr[0][1]['rev24'])}亿元，占比{pct(dr[0][1]['rev24']/rev24*100)}；"
         f"{dr[1][0]}{W2Y(dr[1][1]['rev24']):.2f}亿元，占比{pct(dr[1][1]['rev24']/rev24*100)}；"
         f"{dr[2][0]}{W2Y(dr[2][1]['rev24']):.2f}亿元，占比{pct(dr[2][1]['rev24']/rev24*100)}。")
set_para(doc.paragraphs[24], new_p24)

# ---------- idx25: 收入增长率前三 ----------
g3=dgrowth_all[:3]
new_p25=(f"从销售（营业）收入总额增长率来看，2024年度排名前三位的所属行政区分别为"
         f"{g3[0][0]}（{pct(g3[0][2])}）、{g3[1][0]}（{pct(g3[1][2])}）和{g3[2][0]}（{pct(g3[2][2])}）。")
set_para(doc.paragraphs[25], new_p25)

# ---------- idx26: 户均收入 ----------
new_p26=(f"从所属行政区户均销售（营业）收入来看，"
         + "、".join([f"{k}（{a:,.0f}万元）" for k,a in davg if a>avg_rev])
         + f"高于全市户均水平（{avg_rev:,.0f}万元）。")
set_para(doc.paragraphs[26], new_p26)

# ---------- idx27: 纳税前三区 ----------
dt=sorted(dd.items(),key=lambda x:-x[1]['tax24'])[:3]
new_p27=(f"从纳税总额来看，2024年度排名前三位的所属行政区分别为"
         f"{dt[0][0]}{W2Y(dt[0][1]['tax24']):.2f}亿元，占比{pct(dt[0][1]['tax24']/tax24*100)}；"
         f"{dt[1][0]}{W2Y(dt[1][1]['tax24']):.2f}亿元，占比{pct(dt[1][1]['tax24']/tax24*100)}；"
         f"{dt[2][0]}{W2Y(dt[2][1]['tax24']):.2f}亿元，占比{pct(dt[2][1]['tax24']/tax24*100)}。")
set_para(doc.paragraphs[27], new_p27)

# ---------- idx28: 纳税增长率前三 ----------
dtg=[(k,v,(v['tax24']-v['tax23'])/v['tax23']*100) for k,v in dd.items() if v['tax23']>50]
dtg.sort(key=lambda x:-x[2]); dtg3=dtg[:3]
new_p28=(f"从纳税总额增长率来看，2024年度排名前三位的所属行政区分别为"
         f"{dtg3[0][0]}（{pct(dtg3[0][2])}）、{dtg3[1][0]}（{pct(dtg3[1][2])}）和{dtg3[2][0]}（{pct(dtg3[2][2])}）。")
set_para(doc.paragraphs[28], new_p28)

# ---------- idx29: 户均纳税 ----------
dtx=[(k,v['tax24']/v['n']) for k,v in dd.items() if v['n']>0 and v['tax24']/v['n']>tax24/N]
dtx.sort(key=lambda x:-x[1])
new_p29=(f"从所属行政区户均纳税总额来看，"
         + "、".join([f"{k}（{a:,.0f}万元）" for k,a in dtx])
         + f"高于全市户均水平（{tax24/N:,.0f}万元）。")
set_para(doc.paragraphs[29], new_p29)

# ===== Section 二、(一) 收入情况 =====
# idx32: heading
set_para(doc.paragraphs[32], "（一）销售（营业）收入情况")
# idx33
new_p33=(f"2024年度，年报企业销售（营业）收入合计{W2Y(rev24)}亿元，同比上升{pct(gr(rev24,rev23))}，"
         f"在上一年度增长{pct(gr(rev23,rev22))}的基础上延续增长态势。全市年报企业户均销售（营业）收入{avg_rev:,.0f}万元，"
         f"同比上升{pct(gr(avg_rev,avg_rev23))}。")
set_para(doc.paragraphs[33], new_p33)

# idx34
r1=range_stat(*ranges_def[0][:2]); r2=range_stat(*ranges_def[1][:2]); r3=range_stat(*ranges_def[2][:2])
below1yi=N-r1[0]-r2[0]-r3[0]  # actually count those <1亿
n_below=sum(1 for x in D if x['rev24'] is not None and x['rev24']<10000)
new_p34=f"年报企业的销售（营业）收入在1亿元以下的企业共{n_below}家，占年报企业数的{pct(n_below/N*100)}，其中："
set_para(doc.paragraphs[34], new_p34)

# idx35: 100万以下
new_p35=(f"100万元以下的企业{r1[0]}家，占年报企业数的{pct(r1[0]/N*100)}；"
         f"共实现销售（营业）收入{W2Y(r1[1]):.2f}亿元，占比{pct(r1[1]/rev24*100,1)}，同比{('下降' if r1[2]<0 else '增长')}{pct(abs(r1[2]))}；")
set_para(doc.paragraphs[35], new_p35)

# idx36: 100万-1000万
new_p36=(f"100万元至1000万元之间的企业{r2[0]}家，占年报企业数的{pct(r2[0]/N*100)}；"
         f"销售（营业）收入合计{W2Y(r2[1]):.2f}亿元，占比{pct(r2[1]/rev24*100,1)}，同比{('下降' if r2[2]<0 else '增长')}{pct(abs(r2[2]))}；")
set_para(doc.paragraphs[36], new_p36)

# idx37: 1000万-1亿
new_p37=(f"1000万元至1亿元之间的企业{r3[0]}家，占年报企业数的{pct(r3[0]/N*100)}；"
         f"销售（营业）收入合计{W2Y(r3[1]):.2f}亿元，占比{pct(r3[1]/rev24*100,1)}，同比{('下降' if r3[2]<0 else '增长')}{pct(abs(r3[2]))}（见表2-1-1）。")
set_para(doc.paragraphs[37], new_p37)

# idx43: 超10亿
over10=range_stat(100000,float('inf'))
new_p43=(f"年报企业销售（营业）收入超过10亿元的企业{over10[0]}家，占年报企业数的{pct(over10[0]/N*100,1)}；"
         f"共实现销售（营业）收入{W2Y(over10[1])}亿元，占比{pct(over10[1]/rev24*100)}，同比{('下降' if over10[2]<0 else '增长')}{pct(abs(over10[2]))}。"
         f"头部企业贡献了近{pct(over10[1]/rev24*100,0)}的销售（营业）收入。")
set_para(doc.paragraphs[43], new_p43)

# idx44: top企业
t1=top_rev[0]
new_p44=(f"其中，2024年度销售（营业）收入最高的企业为{t1['name']}，达{W2Y(t1['rev24'])}亿元，"
         f"同比{('下降' if gr(t1['rev24'],t1['rev23'] or 1)<0 else '增长')}{pct(abs(gr(t1['rev24'],t1['rev23'] or t1['rev24'])))}（见表2-1-2）。")
set_para(doc.paragraphs[44], new_p44)

# idx47: 浦东领先
new_p47=(f"从所属行政区来看，{dr[0][0]}企业实现的营业收入最高，营收占比超过10%的区共{sum(1 for k,v in dd.items() if v['rev24']/rev24*100>10)}个。其中：")
set_para(doc.paragraphs[47], new_p47)

# idx48: 收入前三区详情
new_p48=(f"{dr[0][0]}排名首位，销售（营业）收入{W2Y(dr[0][1]['rev24'])}亿元，占比{pct(dr[0][1]['rev24']/rev24*100)}，"
         f"同比{('下降' if gr(dr[0][1]['rev24'],dr[0][1]['rev23'])<0 else '增长')}{pct(abs(gr(dr[0][1]['rev24'],dr[0][1]['rev23'])))}；"
         f"其次为{dr[1][0]}，销售（营业）收入{W2Y(dr[1][1]['rev24']):.2f}亿元，占比{pct(dr[1][1]['rev24']/rev24*100)}，"
         f"同比{('下降' if gr(dr[1][1]['rev24'],dr[1][1]['rev23'])<0 else '增长')}{pct(abs(gr(dr[1][1]['rev24'],dr[1][1]['rev23'])))}；"
         f"{dr[2][0]}排名第三，销售（营业）收入{W2Y(dr[2][1]['rev24']):.2f}亿元，占比{pct(dr[2][1]['rev24']/rev24*100)}，"
         f"同比{('下降' if gr(dr[2][1]['rev24'],dr[2][1]['rev23'])<0 else '增长')}{pct(abs(gr(dr[2][1]['rev24'],dr[2][1]['rev23'])))}（见图2-1-1）。")
set_para(doc.paragraphs[48], new_p48)

# idx54: 增长区数
ngrow=sum(1 for k,v in dd.items() if v['rev23']>100 and (v['rev24']-v['rev23'])/v['rev23']>0)
new_p54=f"{ngrow}个区的销售（营业）收入同比实现增长，{g3[0][0]}同比增长最高。其中："
set_para(doc.paragraphs[54], new_p54)

# idx55
below_city=[k for k,v in dd.items() if v['rev23']>100 and (v['rev24']-v['rev23'])/v['rev23']<gr(rev24,rev23)]
new_p55=(f"{g3[0][0]}销售（营业）收入同比增长排名首位，同比增长{pct(g3[0][2])}；"
         f"其次是{g3[1][0]}，同比增长{pct(g3[1][2])}；{g3[2][0]}排名第三，同比增长{pct(g3[2][2])}。"
         f"{('、'.join(below_city))}等区销售（营业）收入同比低于全市水平（{pct(gr(rev24,rev23))}）（见图2-1-2）。")
set_para(doc.paragraphs[55], new_p55)

# idx59
new_p59=f"{len(above_avg)}个区的户均销售（营业）收入超过全市水平，{len(dd)-len(above_avg)}个区低于全市水平。"
set_para(doc.paragraphs[59], new_p59)

# idx60
aa=[(k,a) for k,a in davg if a>avg_rev][:3]
new_p60=(f"从所属行政区来看，" + "、".join([f"{k}" for k,a in aa]) + f"等区年报企业户均销售（营业）收入超过全市平均水平。"
         f"其中，{aa[0][0]}排名第一，户均销售（营业）收入{aa[0][1]:,.0f}万元，同比上升{pct(gr(dd[aa[0][0]]['rev24']/dd[aa[0][0]]['n'], dd[aa[0][0]]['rev23']/dd[aa[0][0]]['n']))}；"
         f"其次为{aa[1][0]}，户均销售（营业）收入{aa[1][1]:,.0f}万元，同比上升{pct(gr(dd[aa[1][0]]['rev24']/dd[aa[1][0]]['n'], dd[aa[1][0]]['rev23']/dd[aa[1][0]]['n']))}；"
         f"{aa[2][0]}排名第三，户均销售（营业）收入{aa[2][1]:,.0f}万元（见图2-1-3）。")
set_para(doc.paragraphs[60], new_p60)

# idx64
davg_grow=[(k,gr(v['rev24']/v['n'],v['rev23']/v['n'])) for k,v in dd.items() if v['rev23']>0 and v['rev24']/v['n']>0]
davg_grow.sort(key=lambda x:-x[1])
grow_list=[k for k,g in davg_grow if g>0]
new_p64=f"{len(grow_list)}个区的户均销售（营业）收入同比实现增长，{davg_grow[0][0]}增幅最大。"
set_para(doc.paragraphs[64], new_p64)

# idx65
new_p65=(f"户均销售（营业）收入较上一年度实现增长的所属行政区有{len(grow_list)}个，"
         f"分别为" + "、".join(grow_list) + f"等。其余区的户均销售（营业）收入同比低于全市水平（见图2-1-4）。")
set_para(doc.paragraphs[65], new_p65)

# idx69: 产业
new_p69="从产业分布来看，第三产业企业实现的营业收入最高，但第二产业增速更快。"
set_para(doc.paragraphs[69], new_p69)

# idx70
c3r=cy.get('第三产业',{'rev24':0,'rev23':0}); c2r=cy.get('第二产业',{'rev24':0,'rev23':0}); c1r=cy.get('第一产业',{'rev24':0,'rev23':0})
new_p70=(f"2024年度，第三产业销售（营业）收入最高，达{W2Y(c3r['rev24'])}亿元，占比{pct(c3r['rev24']/rev24*100)}，"
         f"同比{('下降' if gr(c3r['rev24'],c3r['rev23'])<0 else '上升')}{pct(abs(gr(c3r['rev24'],c3r['rev23'])))}；"
         f"其次为第二产业，销售（营业）收入{W2Y(c2r['rev24'])}亿元，占比{pct(c2r['rev24']/rev24*100)}，"
         f"同比{('下降' if gr(c2r['rev24'],c2r['rev23'])<0 else '上升')}{pct(abs(gr(c2r['rev24'],c2r['rev23'])))}。")
set_para(doc.paragraphs[70], new_p70)

# idx71
over5=sum(1 for k,v in ind.items() if v['rev24']/rev24*100>5)
new_p71=f"从行业来看，{ind_rev_rank[0][0]}的销售（营业）收入最高，营收占比超过5%的行业共{over5}个。"
set_para(doc.paragraphs[71], new_p71)

# idx72
ir3=ind_rev_rank[:3]
share3=sum(v['rev24'] for k,v in ir3)/rev24*100
new_p72=(f"2024年度，年报企业销售（营业）收入排名前三位的行业分别为{ir3[0][0]}、{ir3[1][0]}、{ir3[2][0]}，"
         f"三个行业贡献了{pct(share3)}的年报企业销售（营业）收入。其中，{ir3[0][0]}企业销售（营业）收入{W2Y(ir3[0][1]['rev24'])}亿元，占比{pct(ir3[0][1]['rev24']/rev24*100)}，"
         f"同比{('下降' if gr(ir3[0][1]['rev24'],ir3[0][1]['rev23'])<0 else '增长')}{pct(abs(gr(ir3[0][1]['rev24'],ir3[0][1]['rev23'])))}；"
         f"{ir3[1][0]}企业销售（营业）收入{W2Y(ir3[1][1]['rev24'])}亿元，占比{pct(ir3[1][1]['rev24']/rev24*100)}，"
         f"同比{('下降' if gr(ir3[1][1]['rev24'],ir3[1][1]['rev23'])<0 else '增长')}{pct(abs(gr(ir3[1][1]['rev24'],ir3[1][1]['rev23'])))}；"
         f"{ir3[2][0]}企业销售（营业）收入{W2Y(ir3[2][1]['rev24']):.2f}亿元，占比{pct(ir3[2][1]['rev24']/rev24*100)}，"
         f"同比{('下降' if gr(ir3[2][1]['rev24'],ir3[2][1]['rev23'])<0 else '增长')}{pct(abs(gr(ir3[2][1]['rev24'],ir3[2][1]['rev23'])))}（见图2-1-5）。")
set_para(doc.paragraphs[72], new_p72)

# ---------- table captions (year) ----------
for idx in [41,46]:
    pass  # 表号保持，正文已说明年度

doc.save(OUT)
print("SAVED:", OUT)