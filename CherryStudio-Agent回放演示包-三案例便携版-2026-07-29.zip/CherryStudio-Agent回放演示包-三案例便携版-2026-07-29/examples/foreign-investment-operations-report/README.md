# 数据报告撰写 Agent 回放案例

本案例来自 Cherry Studio v2 中 Agent「数据报告撰写」的成功历史会话「生成2024年度外商投资企业运营报告与数据分析表」，不是人工改写的相似剧本。

## 录制基线

- Agent：`数据报告撰写`
- 会话 ID：`939cc4b3-a717-45ae-a229-b65d66b1b708`
- 模型：`GLM-5.2`
- 权限：`bypassPermissions` / Full Auto
- 原始耗时：`884.630 秒`
- Provider 回合：`46`
- 原始 Assistant 内容块：`128`
- 工具调用：`57`
  - `Bash` × 36
  - `TaskCreate` × 3
  - `TaskUpdate` × 6
  - `Edit` × 8
  - `Read` × 2
  - `memory` × 1
  - `report_artifacts` × 1

原始提示词：

```text
读取目录下的数据文件，更新本月运营数据到报告模板里。生成数据分析表格，两张Sheet：一张原始明细，一张重点指标趋势摘要。基于新数据，把运营报告更新到本月版本，刷新结论。
```

原始附件：

- `2023上海市外商投资企业运营报告_模板.docx`
- `数据0528.xlsx`

最终产物：

- `2024上海市外商投资企业运营报告.docx`（Cherry 右侧原生预览）
- `上海市外商投资企业运营数据分析表.xlsx`（保留为原始下载文件）
- `上海市外商投资企业运营数据分析表_预览.html`（Cherry 右侧预览两张 Sheet，并可下载原始 XLSX）

## 复刻方式

1. Fake Provider 按原 Session 的顺序回放 reasoning、text 和 tool use。
2. `Bash` 保留原工具卡标题、录制输出、错误节点与时长，但不重新执行搜索、安装依赖或生成任务。
3. 两个关键脚本在对应节点以录制时的中间状态落盘，使 8 次 Cherry Studio 原生 `Edit` 和 2 次 `Read` 能真实执行。
4. 最终 DOCX、XLSX 与 XLSX 的 HTML 预览镜像在录制的生成节点从 `assets/` 安全复制到会话工作目录。
5. `memory` 调用使用离线录制结果，不写入当前机器的真实 Agent 记忆。
6. `report_artifacts` 仍由 Cherry Studio 原生执行，只注册 DOCX 与 XLSX 预览 HTML 两张文件卡；两张卡都可在 Cherry 右侧直接预览。

## 启动

在终端中设定：

```bash
PACKAGE_DIR="/绝对路径/CherryStudio-Agent回放演示包-三案例便携版-2026-07-29"
CASE_DIR="$PACKAGE_DIR/examples/foreign-investment-operations-report"
OUTPUT_DIR="$PACKAGE_DIR/outputs/foreign-investment-operations-report"
mkdir -p "$OUTPUT_DIR"
```

启动 Provider：

```bash
node "$PACKAGE_DIR/tool/provider-server.mjs" \
  --routes "$PACKAGE_DIR/routes.json" \
  --port 8402
```

在 Cherry Studio 中导入离线 MCP：

```json
{
  "mcpServers": {
    "data-report-replay": {
      "command": "/usr/local/bin/node",
      "args": [
        "$PACKAGE_DIR/tool/mcp-toolbox.mjs",
        "--script",
        "$PACKAGE_DIR/examples/foreign-investment-operations-report",
        "--out-dir",
        "$PACKAGE_DIR/outputs/foreign-investment-operations-report"
      ]
    }
  }
}
```

Agent 配置：

- 主模型、计划模型、小模型全部使用本地 Provider 的 `GLM-5.2`。
- 权限设为 `Full Auto Mode`。
- 开启 `Bash`、`Read`、`Edit`、Task 和 artifact 相关原生工具。
- 开启 `data-report-replay` MCP（仅用于离线回放 memory 结果）。
- 会话工作目录设为 `$PACKAGE_DIR/outputs/foreign-investment-operations-report` 对应的绝对路径。

新建会话后，原样发送固定提示词。

## 验收

- Provider 日志从 `turn 0` 开始，最终播放到 `turn 45`。
- 对话中保留生成 Excel 时的 1 次错误和生成报告时的 3 次错误，以及后续数据口径纠错。
- 对话中出现 8 次原生 Edit 卡片、2 次 Read 卡片。
- 输出目录出现 DOCX、原始 XLSX 与 XLSX 预览 HTML。
- 最后一次 `report_artifacts` 只注册 DOCX 与 XLSX 预览 HTML，不显示 Cherry 当前无法内置预览的 XLSX 文件卡。
- 在 XLSX 预览 HTML 中可切换「重点指标趋势摘要」「原始明细」，并下载原始 XLSX。
- 最终正文以「已全部完成。以下是我的工作成果汇报：」开始。

## 边界

- 这是成功 Session 的确定性回放，不会根据其他数据附件重新计算。
- v2 数据库不保存逐 token 帧；内容、顺序和总耗时可保真，单步流式节奏为重建值。
- `source/session.json` 含原始对话内容，对外发布前应再次审查数据和路径。
