# gzh-design 公众号排版回放案例

本案例来自 Cherry Studio v2 本机会话：

- 会话 ID：`53adcd5e-f799-445a-ae76-c6358c115b4d`
- 会话标题：`用户要求将文档转换为微信公众号可用的HTML并嵌入图片`
- 原始总耗时：`155,318 ms`
- 回放轮数：32

## 演示输入

在全新 Agent 会话中附上 `assets/Cherry Studio宣传公众号文章.docx`，发送：

```text
/gzh-design 把这个文档做成一键排成可直接粘贴进微信公众号编辑器的精致 HTML，把html文件直接给我,然后把word文档里的两个照片也一起放进去，其他的地方的待补素材去掉
```

## 启动

```bash
PACKAGE_DIR="/绝对路径/CherryStudio-Agent回放演示包-三案例便携版-2026-07-29"
OUTPUT_DIR="$PACKAGE_DIR/outputs/gzh-design-demo"
mkdir -p "$OUTPUT_DIR"

node "$PACKAGE_DIR/tool/provider-server.mjs" \
  --routes "$PACKAGE_DIR/routes.json" \
  --port 8402
```

Cherry Studio 会话工作目录必须设置为同一个 `OUTPUT_DIR`。主模型、计划模型和小模型均使用本地回放 Provider 的 `MiniMax-M3`（模型 ID：`minimax/minimax-m3`），权限模式设为 `Full Auto Mode`。

## 依赖

为了保留原会话的 `Skill`、`Read` 和校验工具卡，本包已经内置独立的 `gzh-design-replay` 技能：

```text
$PACKAGE_DIR/skills/gzh-design-replay
```

部署时将它注册到目标 Mac 的 Cherry Studio 技能目录。剧本内部读取和校验使用包内相对路径，不依赖原机器用户名。

## 安全回放策略

- 原始 Word 已放入 `assets/`，回放时复制到会话目录。
- Word 提取和图片抽取由 `gzh-design-replay/scripts/extract_docx.py` 真实执行。
- 约 484 KB 的最终 HTML 已预生成，回放到“生成 HTML”步骤时安全复制，而不重复执行原会话中的长内联生成命令。
- 预览页、HTML 校验和 `report_artifacts` 仍由 Cherry Studio 原生工具真实执行。
- `report_artifacts` 只登记 `..._预览.html`；点击唯一文件卡后，在 Cherry 右侧面板内置预览。
- 产物中的两张 PNG 使用 Base64 内嵌；作者和待补素材占位均已清零。

## 预期文件

- 内部中间文件（不登记交付）：`article_排版_樱桃粉(red-white).html`
- 唯一交付文件：`article_排版_樱桃粉(red-white)_预览.html`

干净正文应通过 `validate_gzh_html.py`，两张图片均可离线显示，预览页右上角的一键复制按钮可正常工作。
