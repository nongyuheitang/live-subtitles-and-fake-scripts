# 具身智能行业调研报告回放案例

本案例来自 Cherry Studio 本地历史会话 `具身智能行业调研报告与PPT生成`，不是人工重新编写的相似案例。

## 录制基线

- 会话 ID：`2f74116e-ed23-4861-9bed-0dbc5fabe2b0`
- 原始提示词：`帮我做一份关于具身智能赛道的行业调研报告，要包括：市场规模、核心玩家、技术路线、投资热点，最后输出成PPT格式。`
- 原始模型：`GLM-5.2`
- 权限模式：`bypassPermissions` / Full Auto
- 原始耗时：`409.652 秒`
- 回放轮次：`17`
- 工具调用：`22` 次
  - `web_search` × 6
  - `web_fetch` × 2
  - `Bash` × 9
  - `Write` × 2
  - `Edit` × 2
  - `report_artifacts` × 1
- 交付物：`具身智能赛道行业调研报告.pptx`，12 页，16:9 深色科技风

## 回放实现

1. Fake Provider 逐块回放原会话的思考、正文和工具调用。
2. `web_search` / `web_fetch` 由 replay MCP 返回原会话录制结果，不重新联网。
3. 原始 `Bash` 命令全部改成安全延时；生成 PPT 的两个节点改成复制已验证资产。
4. `Write` / `Edit` 仍由 Cherry Studio 原生工具执行，因此生成脚本和修改卡片保持原生样式。
5. `report_artifacts` 仍由 Cherry Studio 自带工具执行，使 PPT 真正出现在右侧产物区。
6. 17 轮的目标时长合计严格等于原会话的 `409.652 秒`；实际 UI 还会叠加少量 SDK、磁盘和渲染开销。

`source/session.json` 是完整原始会话导出，仅用于本地核对；再次对外分发前应按包根目录安全要求检查正文、路径和来源内容。

## 启动

先设置路径：

```bash
PACKAGE_DIR="/绝对路径/CherryStudio-Agent回放演示包-三案例便携版-2026-07-29"
CASE_DIR="$PACKAGE_DIR/examples/embodied-intelligence-report"
OUTPUT_DIR="$PACKAGE_DIR/outputs/embodied-intelligence-report"
mkdir -p "$OUTPUT_DIR"
```

启动 Fake Provider：

```bash
node "$PACKAGE_DIR/tool/provider-server.mjs" \
  --routes "$PACKAGE_DIR/routes.json" \
  --port 8402
```

在 Cherry Studio 中添加 replay MCP。当前机器的 Node 路径为 `/usr/local/bin/node`；换机器时先运行 `command -v node` 并替换：

```json
{
  "mcpServers": {
    "cherry-tools": {
      "command": "/usr/local/bin/node",
      "args": [
        "$PACKAGE_DIR/tool/mcp-toolbox.mjs",
        "--script",
        "$PACKAGE_DIR/examples/embodied-intelligence-report",
        "--out-dir",
        "$PACKAGE_DIR/outputs/embodied-intelligence-report"
      ]
    }
  }
}
```

Agent 配置：

- 主模型、计划模型、小模型全部选择本地 Provider 的 `GLM-5.2`。
- 权限选择 `Full Auto Mode`。
- 启用 `Bash`、`Write`、`Edit`、artifact 相关原生工具。
- 启用刚添加的 `cherry-tools` replay MCP。沿用这个显示名是为了让工具卡片标题与原会话一致；如果当前版本禁止重名，可改为 `research-replay`，只会改变卡片的服务器前缀。
- 保留 Cherry Studio 自带的 `report_artifacts` 工具。
- 会话工作目录设为 `$PACKAGE_DIR/outputs/embodied-intelligence-report` 对应的绝对路径。

必须新建会话，然后原样发送：

```text
帮我做一份关于具身智能赛道的行业调研报告，要包括：市场规模、核心玩家、技术路线、投资热点，最后输出成PPT格式。
```

## 验收

- Provider 首轮日志应显示 `turn 0`。
- 工具绑定中 `web_search` / `web_fetch` 应指向带 `[replay-demo]` 描述的 replay MCP 工具。
- 全程共播放 17 个 provider turn。
- 输出目录出现 `具身智能赛道行业调研报告.pptx`。
- 对话最后出现 1 个可点击产物，右侧可预览 12 页。
- 最终正文从“报告已经做好啦！”开始，并包含 12 页报告结构与核心数据亮点。

## 已知差异

- v2 数据库不保存逐 token 帧，因此流式打字节奏按原始整段耗时和 thinking 时间重建；内容、顺序、工具输入、录制搜索结果和最终文件保持一致。
- 原始 PPT 本身在第 4、5、7、8 页存在少量底部元素重叠，本案例为忠实复刻没有修改这些页面。
