#!/usr/bin/env node
/**
 * Fake LLM provider server for demo replay.
 *
 * Modes:
 *   replay (default): serve scripted SSE responses from a script directory.
 *   record          : transparent proxy to a real upstream, dumping request/SSE frames to ./recorded.
 *
 * Endpoints:
 *   POST /v1/messages              Anthropic Messages (SSE)   <- claude-agent-sdk direct route
 *   POST /v1/messages/count_tokens Anthropic token count stub
 *   POST /v1/chat/completions      OpenAI Chat (SSE)          <- Cherry gateway route fallback
 *   GET  /v1/models                model list (both dialects)
 *
 * Usage:
 *   node provider-server.mjs --script scripts/server-inspection --out-dir ~/Desktop/demo-out [--port 8402]
 *   node provider-server.mjs --mode record --upstream https://open.bigmodel.cn/api/anthropic [--port 8402]
 *     (record reads the upstream key from env REPLAY_UPSTREAM_KEY)
 */
import fs from 'node:fs'
import http from 'node:http'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

// ---------- args ----------
const args = {}
for (let i = 2; i < process.argv.length; i++) {
  const a = process.argv[i]
  if (a.startsWith('--')) args[a.slice(2)] = process.argv[i + 1]?.startsWith('--') ? true : process.argv[++i]
}
const MODE = args.mode ?? 'replay'
const PORT = Number(args.port ?? 8402)
const SCRIPT_DIR = args.script ? path.resolve(__dirname, args.script) : path.join(__dirname, 'scripts/server-inspection')
const OUT_DIR = path.resolve(args['out-dir'] ?? path.join(SCRIPT_DIR, 'out'))
const ROUTES_FILE = args.routes ? path.resolve(__dirname, args.routes) : null
const UPSTREAM = args.upstream?.replace(/\/$/, '')
const UPSTREAM_KEY = process.env.REPLAY_UPSTREAM_KEY

const log = (...xs) => console.error(`[provider ${new Date().toISOString().slice(11, 19)}]`, ...xs)

// ---------- script loading (replay mode) ----------
let script = null
let replayCases = []
let routerFallbacks = [{ whenBodyContains: 'title', text: '新会话' }, { whenBodyContains: '', text: 'OK' }]
if (MODE === 'replay') {
  if (ROUTES_FILE) {
    const config = JSON.parse(fs.readFileSync(ROUTES_FILE, 'utf8'))
    routerFallbacks = config.fallbacks ?? routerFallbacks
    replayCases = (config.routes ?? []).map((route) => {
      const scriptDir = path.resolve(path.dirname(ROUTES_FILE), route.script)
      const outDir = path.resolve(path.dirname(ROUTES_FILE), route.outDir ?? path.join(scriptDir, 'out'))
      const routeScript = JSON.parse(fs.readFileSync(path.join(scriptDir, 'script.json'), 'utf8'))
      return {
        name: route.name ?? routeScript.name,
        script: routeScript,
        scriptDir,
        outDir,
        match: { anyOf: route.anyOf ?? routeScript.match?.anyOf ?? [] },
        stateDir: path.join(scriptDir, '.state')
      }
    })
    if (!replayCases.length) throw new Error(`routes config has no routes: ${ROUTES_FILE}`)
    for (const c of replayCases) {
      fs.mkdirSync(path.join(c.stateDir, 'requests'), { recursive: true })
      log(`route "${c.name}" -> script "${c.script.name}" — ${c.script.turns.length} turns, match=${JSON.stringify(c.match.anyOf)}`)
      log(`route "${c.name}" output dir: ${c.outDir}`)
    }
  } else {
    script = JSON.parse(fs.readFileSync(path.join(SCRIPT_DIR, 'script.json'), 'utf8'))
    replayCases = [{
      name: script.name,
      script,
      scriptDir: SCRIPT_DIR,
      outDir: OUT_DIR,
      match: script.match ?? { anyOf: [] },
      stateDir: path.join(SCRIPT_DIR, '.state')
    }]
    log(`script "${script.name}" — ${script.turns.length} turns, match=${JSON.stringify(script.match.anyOf)}`)
    log(`output dir: ${OUT_DIR}`)
  }
}
const STATE_DIR = ROUTES_FILE ? path.join(path.dirname(ROUTES_FILE), '.state') : path.join(SCRIPT_DIR, '.state')
fs.mkdirSync(path.join(STATE_DIR, 'requests'), { recursive: true })
let reqSeq = 0

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const rid = (p) => p + Math.random().toString(36).slice(2, 10)

/** Expand `{{OUTPUT_DIR}}` (and friends) inside any scripted tool input. */
function expandVars(value, replayCase) {
  const outDir = replayCase?.outDir ?? OUT_DIR
  const scriptDir = replayCase?.scriptDir ?? SCRIPT_DIR
  if (typeof value === 'string') return value.replaceAll('{{OUTPUT_DIR}}', outDir).replaceAll('{{SCRIPT_DIR}}', scriptDir)
  if (Array.isArray(value)) return value.map((item) => expandVars(item, replayCase))
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, expandVars(v, replayCase)]))
  }
  return value
}

/** Split text into frames of ~n chars without breaking surrogate pairs. */
function chunkText(text, n) {
  const out = []
  for (const seg of text) {
    if (!out.length || out[out.length - 1].length >= n) out.push('')
    out[out.length - 1] += seg
  }
  return out.filter((s) => s.length)
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const bufs = []
    req.on('data', (c) => bufs.push(c))
    req.on('end', () => resolve(Buffer.concat(bufs).toString('utf8')))
    req.on('error', reject)
  })
}

function sseHead(res) {
  res.writeHead(200, {
    'content-type': 'text/event-stream; charset=utf-8',
    'cache-control': 'no-cache',
    connection: 'keep-alive',
    'x-request-id': rid('req_')
  })
}

// ---------- replay: request classification ----------
/**
 * Only a real agent turn carries the agent tool schema. Title generation, summarization and
 * other utility calls embed the user's own words — so a bare string match on the body would
 * misclassify them as main-line and burn a scripted turn. Require tools[] first.
 */
function isMainLineRequest(body, bodyStr, replayCase) {
  const toolCount = (body.tools ?? []).length
  if (toolCount === 0) return { main: false, why: 'no tool schema (utility request)' }
  const hint = (replayCase.match?.anyOf ?? []).find((h) => bodyStr.includes(h))
  if (!hint) return { main: false, why: 'no match hint in body' }
  return { main: true, why: `hint "${hint}" + ${toolCount} tools` }
}

function pickFallback(bodyStr, fallbacks) {
  for (const f of fallbacks ?? []) {
    if (!f.whenBodyContains || bodyStr.includes(f.whenBodyContains)) return f
  }
  return { text: 'OK' }
}

function textFromContent(value) {
  if (typeof value === 'string') return value
  if (Array.isArray(value)) return value.map(textFromContent).join('\n')
  if (value && typeof value === 'object') {
    // Route only on human-readable text. In particular, do not recurse into tool_result
    // payloads: recorded file listings can mention another case and must never switch routes.
    if (value.type === 'tool_result') return ''
    if (typeof value.text === 'string') return value.text
  }
  return ''
}

function firstUserPrompt(body) {
  const firstUser = (body.messages ?? []).find((message) => message?.role === 'user')
  return textFromContent(firstUser?.content)
}

function selectReplayCase(body) {
  const prompt = firstUserPrompt(body)
  return replayCases.find((candidate) => (candidate.match?.anyOf ?? []).some((hint) => prompt.includes(hint))) ?? null
}

const COMPLETION_LOCK_EXTENSIONS = /\.(?:xlsx|html?|pptx?)$/i

function contentBlocks(message) {
  if (Array.isArray(message?.content)) return message.content
  return message?.content && typeof message.content === 'object' ? [message.content] : []
}

function isCompletionArtifactTool(block) {
  if (!block || typeof block !== 'object') return false
  const name = block.name ?? block.tool ?? block.function?.name ?? ''
  if (!(name === 'report_artifacts' || name.endsWith('__report_artifacts'))) return false
  const input = block.input ?? block.function?.arguments ?? {}
  let parsedInput = input
  if (typeof input === 'string') {
    try { parsedInput = JSON.parse(input) } catch { return false }
  }
  return (parsedInput?.artifacts ?? []).some((artifact) => COMPLETION_LOCK_EXTENSIONS.test(String(artifact?.path ?? '')))
}

/** Once a target artifact is registered, end the tool round-trip silently and stay silent. */
function hasCompletionArtifactDelivery(body) {
  const messages = body.messages ?? []
  return messages.some((message) =>
    message?.role === 'assistant' && contentBlocks(message).some(isCompletionArtifactTool))
}

/** Resolve what to play for this request: a scripted turn, or a fallback text. */
function resolvePlan(body, bodyStr, replayCase) {
  if (!replayCase) {
    const f = pickFallback(bodyStr, routerFallbacks)
    return { blocks: [{ type: 'text', text: f.text, durationMs: 150 }], stop: 'end_turn', label: 'fallback (no route matched)' }
  }
  const verdict = isMainLineRequest(body, bodyStr, replayCase)
  if (!verdict.main) {
    const f = pickFallback(bodyStr, replayCase.script.fallbacks)
    return { blocks: [{ type: 'text', text: f.text, durationMs: 150 }], stop: 'end_turn', label: `fallback (${verdict.why})` }
  }
  if (hasCompletionArtifactDelivery(body)) {
    return {
      blocks: [{ type: 'text', text: '', durationMs: 50 }],
      stop: 'end_turn',
      label: 'completion lock — silent after artifact delivery'
    }
  }
  // Turn index = how many assistant messages the transcript already holds. Tool round-trips and
  // extra user messages both advance it, so multi-turn conversations index correctly.
  const idx = (body.messages ?? []).filter((m) => m.role === 'assistant').length
  const turn = replayCase.script.turns[idx]
  if (!turn) {
    return {
      blocks: [{ type: 'text', text: '（演示剧本已播放完毕，请新开会话重新开始。）', durationMs: 300 }],
      stop: 'end_turn',
      label: `overrun — turn ${idx} not in script`
    }
  }
  return { blocks: turn.blocks, stop: turn.stop ?? 'end_turn', label: `turn ${idx}` }
}

// ---------- replay: tool name binding ----------
/**
 * Cherry registers each MCP server into the SDK under an internal UUID, so the wire name is
 * `mcp__<uuid>__bash`, never `mcp__toolbox__bash`. Bind logical names from the request's own
 * tools[] on every call — that makes renaming the MCP server, re-adding it, or a UUID change
 * a non-event. Fail closed when a scripted tool is absent: a guessed name would surface as
 * "No such tool available" mid-demo.
 */
/** Claude Code builtin tools — bare wire names that map to Cherry's native tool cards. */
const BUILTIN_TOOL_NAMES = new Set([
  'Bash', 'BashOutput', 'Read', 'Write', 'Edit', 'MultiEdit', 'Glob', 'Grep', 'Search',
  'TodoWrite', 'Task', 'TaskOutput', 'TaskStop', 'TaskCreate', 'TaskGet', 'TaskUpdate', 'TaskList',
  'WebSearch', 'WebFetch', 'NotebookEdit', 'ExitPlanMode', 'Skill', 'ToolSearch',
  'AskUserQuestion', 'ListMcpResources', 'ReadMcpResource'
])

function buildToolNameMap(bodyTools) {
  const map = {}
  for (const t of bodyTools ?? []) {
    const name = t?.name ?? t?.function?.name
    const m = /^mcp__(.+)__([A-Za-z0-9_-]+)$/.exec(name ?? '')
    if (!m) continue
    const description = t?.description ?? t?.function?.description ?? ''
    const replayPreferred = String(description).includes('[replay-demo]')
    if (!(m[2] in map) || replayPreferred) map[m[2]] = name
  }
  return map
}

const loggedBindings = new Set()
function resolveToolName(shortName, map, planLabel) {
  // Builtin SDK tools (Bash / Read / Write / TodoWrite / …) travel under their bare name — that
  // exact string is what selects the native tool card in the renderer, so pass it through
  // untouched. They really execute, so a script must keep their input harmless (see README).
  if (BUILTIN_TOOL_NAMES.has(shortName)) return shortName
  const full = map[shortName]
  if (!full) {
    const available = Object.keys(map).sort().join(', ') || '(none)'
    throw new Error(
      `scripted tool "${shortName}" is not registered in this request (${planLabel}). ` +
        `Available: ${available}. Check the MCP server is enabled on this agent.`
    )
  }
  return full
}

// ---------- replay: Anthropic SSE ----------
async function playAnthropic(res, plan, model, toolMap, replayCase) {
  const send = (event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`)
  let outTokens = 0
  send('message_start', {
    type: 'message_start',
    message: {
      id: rid('msg_'), type: 'message', role: 'assistant', content: [], model,
      stop_reason: null, stop_sequence: null,
      usage: { input_tokens: 2048, output_tokens: 1, cache_creation_input_tokens: 0, cache_read_input_tokens: 0 }
    }
  })
  let index = 0
  for (const block of plan.blocks) {
    const dur = Math.max(50, block.durationMs ?? 1000)
    if (block.type === 'text' || block.type === 'thinking') {
      const isThink = block.type === 'thinking'
      send('content_block_start', {
        type: 'content_block_start', index,
        content_block: isThink ? { type: 'thinking', thinking: '' } : { type: 'text', text: '' }
      })
      const frames = chunkText(expandVars(block.text, replayCase), replayCase?.script.textCharsPerFrame ?? 3)
      const gap = dur / Math.max(1, frames.length)
      for (const f of frames) {
        send('content_block_delta', {
          type: 'content_block_delta', index,
          delta: isThink ? { type: 'thinking_delta', thinking: f } : { type: 'text_delta', text: f }
        })
        outTokens += Math.ceil(f.length / 2)
        await sleep(gap)
      }
      send('content_block_stop', { type: 'content_block_stop', index })
    } else if (block.type === 'tool_use') {
      send('content_block_start', {
        type: 'content_block_start', index,
        content_block: { type: 'tool_use', id: rid('toolu_'), name: resolveToolName(block.tool, toolMap, plan.label), input: {} }
      })
      const json = JSON.stringify(expandVars(block.input ?? {}, replayCase))
      const frames = chunkText(json, 24)
      const gap = dur / Math.max(1, frames.length)
      for (const f of frames) {
        send('content_block_delta', { type: 'content_block_delta', index, delta: { type: 'input_json_delta', partial_json: f } })
        outTokens += 2
        await sleep(gap)
      }
      send('content_block_stop', { type: 'content_block_stop', index })
    }
    index++
  }
  send('message_delta', { type: 'message_delta', delta: { stop_reason: plan.stop, stop_sequence: null }, usage: { output_tokens: outTokens } })
  send('message_stop', { type: 'message_stop' })
  res.end()
}

// ---------- replay: OpenAI SSE (gateway fallback) ----------
async function playOpenAI(res, plan, model, toolMap, replayCase) {
  const id = rid('chatcmpl-')
  const created = Math.floor(Date.now() / 1000)
  const send = (delta, finish = null) =>
    res.write(`data: ${JSON.stringify({ id, object: 'chat.completion.chunk', created, model, choices: [{ index: 0, delta, finish_reason: finish }] })}\n\n`)
  send({ role: 'assistant', content: '' })
  let toolIdx = 0
  for (const block of plan.blocks) {
    const dur = Math.max(50, block.durationMs ?? 1000)
    if (block.type === 'text' || block.type === 'thinking') {
      const frames = chunkText(expandVars(block.text, replayCase), replayCase?.script.textCharsPerFrame ?? 3)
      const gap = dur / Math.max(1, frames.length)
      for (const f of frames) {
        send(block.type === 'thinking' ? { reasoning_content: f } : { content: f })
        await sleep(gap)
      }
    } else if (block.type === 'tool_use') {
      const json = JSON.stringify(expandVars(block.input ?? {}, replayCase))
      send({ tool_calls: [{ index: toolIdx, id: rid('call_'), type: 'function', function: { name: resolveToolName(block.tool, toolMap, plan.label), arguments: '' } }] })
      const frames = chunkText(json, 24)
      const gap = dur / Math.max(1, frames.length)
      for (const f of frames) {
        send({ tool_calls: [{ index: toolIdx, function: { arguments: f } }] })
        await sleep(gap)
      }
      toolIdx++
    }
  }
  send({}, plan.stop === 'tool_use' ? 'tool_calls' : 'stop')
  res.write('data: [DONE]\n\n')
  res.end()
}

// ---------- record mode: transparent proxy + frame dump ----------
async function recordProxy(req, res, bodyStr, pathname) {
  const seq = ++reqSeq
  const stamp = new Date().toISOString().replace(/[:.]/g, '-')
  const base = path.join(__dirname, 'recorded', `${stamp}-${String(seq).padStart(3, '0')}`)
  fs.mkdirSync(path.dirname(base), { recursive: true })
  fs.writeFileSync(base + '.request.json', bodyStr)
  const headers = { 'content-type': 'application/json', 'anthropic-version': req.headers['anthropic-version'] ?? '2023-06-01' }
  if (UPSTREAM_KEY) {
    headers['x-api-key'] = UPSTREAM_KEY
    headers['authorization'] = `Bearer ${UPSTREAM_KEY}`
  }
  const upstream = await fetch(UPSTREAM + pathname, { method: 'POST', headers, body: bodyStr })
  res.writeHead(upstream.status, { 'content-type': upstream.headers.get('content-type') ?? 'application/json' })
  if (!upstream.body) return res.end()
  const dump = fs.createWriteStream(base + '.frames.ndjson')
  const t0 = Date.now()
  const reader = upstream.body.getReader()
  const dec = new TextDecoder()
  let buf = ''
  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    const s = dec.decode(value, { stream: true })
    res.write(s)
    buf += s
    let nl
    while ((nl = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, nl).trimEnd()
      buf = buf.slice(nl + 1)
      if (line) dump.write(JSON.stringify({ t: Date.now() - t0, line }) + '\n')
    }
  }
  dump.end()
  res.end()
  log(`recorded #${seq} -> ${path.basename(base)}.*`)
}

// ---------- http server ----------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x')
  try {
    if (req.method === 'GET' && url.pathname === '/v1/models') {
      const ids = [...new Set((replayCases.length ? replayCases.map((c) => c.script.model) : [script?.model]).filter(Boolean))]
      if (!ids.length) ids.push('GLM-5.2')
      res.writeHead(200, { 'content-type': 'application/json' })
      return res.end(JSON.stringify({
        object: 'list',
        data: ids.map((id) => ({ id, object: 'model', type: 'model', display_name: id, created: 1735689600, owned_by: 'replay-demo' }))
      }))
    }
    if (req.method === 'POST' && url.pathname === '/v1/messages/count_tokens') {
      await readBody(req)
      res.writeHead(200, { 'content-type': 'application/json' })
      return res.end(JSON.stringify({ input_tokens: 2048 }))
    }
    if (req.method === 'POST' && (url.pathname === '/v1/messages' || url.pathname === '/v1/chat/completions')) {
      const bodyStr = await readBody(req)
      if (MODE === 'record') return recordProxy(req, res, bodyStr, url.pathname)
      const body = JSON.parse(bodyStr || '{}')
      const replayCase = selectReplayCase(body)
      const requestStateDir = replayCase?.stateDir ?? STATE_DIR
      fs.writeFileSync(path.join(requestStateDir, 'requests', `${String(++reqSeq).padStart(3, '0')}.json`), bodyStr)
      const plan = resolvePlan(body, bodyStr, replayCase)
      const toolMap = buildToolNameMap(body.tools)
      if (replayCase && !loggedBindings.has(replayCase.name) && Object.keys(toolMap).length) {
        loggedBindings.add(replayCase.name)
        const scripted = new Set(replayCase.script.turns.flatMap((t) => t.blocks).filter((b) => b.type === 'tool_use').map((b) => b.tool))
        log(`tool binding for route "${replayCase.name}":`)
        for (const s of scripted) log(`    ${s.padEnd(18)} -> ${toolMap[s] ?? '*** NOT REGISTERED ***'}`)
      }
      log(`${url.pathname} model=${body.model} route=${replayCase?.name ?? 'fallback'} -> ${plan.label}`)

      if (body.stream === false) {
        const text = plan.blocks.filter((b) => b.type === 'text').map((b) => b.text).join('')
        res.writeHead(200, { 'content-type': 'application/json' })
        if (url.pathname === '/v1/messages') {
          return res.end(JSON.stringify({
            id: rid('msg_'), type: 'message', role: 'assistant', model: body.model,
            content: [{ type: 'text', text }], stop_reason: 'end_turn', stop_sequence: null,
            usage: { input_tokens: 2048, output_tokens: 64 }
          }))
        }
        return res.end(JSON.stringify({
          id: rid('chatcmpl-'), object: 'chat.completion', created: Math.floor(Date.now() / 1000), model: body.model,
          choices: [{ index: 0, message: { role: 'assistant', content: text }, finish_reason: 'stop' }],
          usage: { prompt_tokens: 2048, completion_tokens: 64, total_tokens: 2112 }
        }))
      }
      sseHead(res)
      if (url.pathname === '/v1/messages') await playAnthropic(res, plan, body.model ?? replayCase?.script.model ?? 'GLM-5.2', toolMap, replayCase)
      else await playOpenAI(res, plan, body.model ?? replayCase?.script.model ?? 'GLM-5.2', toolMap, replayCase)
      return
    }
    res.writeHead(404, { 'content-type': 'application/json' })
    res.end(JSON.stringify({ error: { type: 'not_found_error', message: `no route: ${req.method} ${url.pathname}` } }))
    log(`404 ${req.method} ${url.pathname}`)
  } catch (err) {
    log('ERROR', err?.message ?? err)
    if (!res.headersSent) {
      res.writeHead(500, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ error: { type: 'api_error', message: String(err?.message ?? err) } }))
    } else {
      res.end()
    }
  }
})

server.listen(PORT, '127.0.0.1', () => {
  log(`mode=${MODE} listening on http://127.0.0.1:${PORT}${MODE === 'record' ? ` -> upstream ${UPSTREAM}` : ''}`)
  if (MODE === 'record' && !UPSTREAM_KEY) log('WARNING: REPLAY_UPSTREAM_KEY is not set — upstream calls will be unauthenticated')
})
