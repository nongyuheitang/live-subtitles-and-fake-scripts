#!/usr/bin/env node
/** Fast local acceptance test for a replay case (no Cherry database writes). */
import crypto from 'node:crypto'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const caseDir = path.resolve(process.argv[2] ?? '')
if (!caseDir || !fs.existsSync(path.join(caseDir, 'script.json'))) {
  console.error('用法：node validate-replay-case.mjs <案例目录>')
  process.exit(1)
}

const script = JSON.parse(fs.readFileSync(path.join(caseDir, 'script.json'), 'utf8'))
const outDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cherry-data-report-replay-'))
const expand = (value) => {
  if (typeof value === 'string') return value.replaceAll('{{OUTPUT_DIR}}', outDir).replaceAll('{{SCRIPT_DIR}}', caseDir)
  if (Array.isArray(value)) return value.map(expand)
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, expand(v)]))
  return value
}
const sha256 = (file) => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')

let bashCount = 0
let expectedBashErrors = 0
let editCount = 0
let readCount = 0
let taskCount = 0
let replayMcpCount = 0
let artifactCount = 0

try {
  for (const turn of script.turns) {
    for (const rawBlock of turn.blocks) {
      if (rawBlock.type !== 'tool_use') continue
      const block = expand(rawBlock)
      if (block.tool === 'Bash') {
        bashCount++
        const expectedError = block.input.command.includes("trap 'exit 1' EXIT")
        const fastCommand = block.input.command.replace(/sleep [0-9.]+/g, 'sleep 0.001')
        const result = spawnSync('/bin/zsh', ['-lc', fastCommand], {
          cwd: outDir,
          encoding: 'utf8',
          timeout: 10_000,
          maxBuffer: 32 * 1024 * 1024
        })
        if (expectedError) {
          expectedBashErrors++
          if (result.status === 0) throw new Error(`预期 Bash 失败但实际成功：${block.input.description}`)
        } else if (result.status !== 0) {
          throw new Error(`Bash 回放失败：${block.input.description}\n${result.stderr}`)
        }
      } else if (block.tool === 'Edit') {
        editCount++
        const file = block.input.file_path
        const text = fs.readFileSync(file, 'utf8')
        const matches = text.split(block.input.old_string).length - 1
        if (matches !== 1) throw new Error(`Edit 旧文本匹配数为 ${matches}：${file}`)
        fs.writeFileSync(file, text.replace(block.input.old_string, block.input.new_string))
      } else if (block.tool === 'Read') {
        readCount++
        if (!fs.existsSync(block.input.file_path)) throw new Error(`Read 目标不存在：${block.input.file_path}`)
      } else if (block.tool.startsWith('Task')) {
        taskCount++
      } else if (block.tool === 'report_artifacts') {
        for (const artifact of block.input.artifacts ?? []) {
          if (!fs.existsSync(artifact.path)) throw new Error(`产物未落盘：${artifact.path}`)
          artifactCount++
        }
      } else {
        replayMcpCount++
        if (!rawBlock.result) throw new Error(`MCP 工具没有离线结果：${block.tool}`)
      }
    }
  }

  for (const name of script.source.artifacts ?? []) {
    const actual = path.join(outDir, name)
    const expected = path.join(caseDir, 'assets', name)
    if (sha256(actual) !== sha256(expected)) throw new Error(`产物哈希不一致：${name}`)
  }

  console.log('✅ 快速回放验收通过')
  console.log(`   turns=${script.turns.length} Bash=${bashCount} BashErrors=${expectedBashErrors} Edit=${editCount} Read=${readCount}`)
  console.log(`   Task=${taskCount} ReplayMCP=${replayMcpCount} Artifacts=${artifactCount}`)
} finally {
  fs.rmSync(outDir, { recursive: true, force: true })
}
